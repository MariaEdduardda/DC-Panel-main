import csv
import subprocess
import os
from src.database.db_functions import listar_ocorrencias
from datetime import datetime as dt, date

def format_duration(seconds):
    if seconds is None:
        return "N/A"
    total_seconds = int(round(seconds))
    if total_seconds < 60:
        return f"{total_seconds}s"
    elif total_seconds < 3600:
        m, s = divmod(total_seconds, 60)
        return f"{m}m {s}s"
    else:
        h, r = divmod(total_seconds, 3600)
        m, s = divmod(r, 60)
        return f"{h}h {m}m {s}s"


def exportar_csv():
    caminho_arquivo = f"sheets/ocorrencias-{dt.now().strftime('%d_%m_%Y-%H_%M_%S')}.csv"
    dados = listar_ocorrencias()

    colunas = [
        "id", "tipo", "descricao", "gravidade", "origem",
        "data", "hora", "duracao", "usuario_id"
    ]

    with open(caminho_arquivo, "w", newline="", encoding="utf-8") as arquivo_csv:
        writer = csv.writer(arquivo_csv, delimiter=';')  # << ALTERADO
        
        writer.writerow(colunas)

        for linha in dados:
            linha = list(linha)

            # Força EXCEL a tratar como TEXTO
            try:
                data_excel = dt.strptime(linha[5], "%Y-%m-%d").strftime("%d/%m/%Y")
                linha[5] = f"'{data_excel}"   # <-- AQUI
            except:
                pass

            writer.writerow(linha)

    abrir_pasta_do_arquivo(caminho_arquivo)


def abrir_pasta_do_arquivo(caminho_arquivo):
    caminho_abs = os.path.abspath(caminho_arquivo)
    pasta = os.path.dirname(caminho_abs)

    # Abre o explorador e seleciona o arquivo
    subprocess.Popen(f'explorer /select,"{caminho_abs}"')
